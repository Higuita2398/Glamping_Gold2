from django.apps import AppConfig


class ComodidadesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'comodidades'
